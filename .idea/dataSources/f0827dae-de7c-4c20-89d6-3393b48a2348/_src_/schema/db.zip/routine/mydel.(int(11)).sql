CREATE PROCEDURE `mydel`(`id` INT(11))
  begin
    delete from book where id=bid;
  END