CREATE PROCEDURE `mysave`(`n` VARCHAR(20), `p` DOUBLE(6, 2))
  begin
    insert into book values (null, n , p);
  END