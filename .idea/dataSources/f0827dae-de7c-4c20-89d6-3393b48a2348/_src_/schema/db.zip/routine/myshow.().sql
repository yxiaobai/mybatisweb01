CREATE PROCEDURE `myshow`()
  BEGIN
  select * from book;
end