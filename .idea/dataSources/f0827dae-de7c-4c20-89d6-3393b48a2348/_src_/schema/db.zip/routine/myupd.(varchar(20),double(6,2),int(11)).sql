CREATE PROCEDURE `myupd`(`n` VARCHAR(20), `p` DOUBLE(6, 2), `id` INT(11))
  begin
    update book set bname=n,bprice=p where id = bid;
  END